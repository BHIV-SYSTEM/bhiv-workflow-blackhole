Write-Host 'Uninstalling Niyantran Employee Monitoring V2...' -ForegroundColor Yellow
Get-Process -Name 'NiyantranWin32Helper' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1
$startMenuDir = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Niyantran"
if (Test-Path "$startMenuDir") {
    Remove-Item "$startMenuDir" -Recurse -Force -ErrorAction SilentlyContinue
}
$desktopDir = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
$desktopLnk = "$desktopDir\Niyantran Employee Monitoring V2.lnk"
if (Test-Path "$desktopLnk") {
    Remove-Item "$desktopLnk" -Force -ErrorAction SilentlyContinue
}
if (Test-Path "HKCU:\Software\Classes\niyantran") {
    Remove-Item "HKCU:\Software\Classes\niyantran" -Recurse -Force -ErrorAction SilentlyContinue
}
$uninstallKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\NiyantranMonitoringV2"
if (Test-Path "$uninstallKey") {
    Remove-Item "$uninstallKey" -Recurse -Force -ErrorAction SilentlyContinue
}
$target = "C:\Users\winst\AppData\Local\Temp\NiyantranInstallerDemo"
if (Test-Path "$target") {
    Remove-Item "$target" -Recurse -Force -ErrorAction SilentlyContinue
}
Write-Host 'Niyantran V2 Agent uninstalled cleanly.' -ForegroundColor Green
